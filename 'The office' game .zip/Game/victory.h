
#ifndef VICTORY_H
#define VICTORY_H


#include<QWidget>
#include<mainwindow.h>
#include<QMovie>
#include<QTimer>
#include<QTime>
#include<QGraphicsPixmapItem>
#include<QGraphicsScene>
#include<QGraphicsItem>
#include<QGraphicsView>
#include<QGridLayout>

class Victory:public QWidget
{
public:
    Victory(QWidget *parent = nullptr,QString name=nullptr,int number=0);
private:
    QLabel *Winner;
    QLabel *Frame;
    QLabel *merm;
    QLabel *the_best;
    QString name_of_winner;
    QPushButton *The_end;
    QPushButton *About_creators;
    QPushButton *Restart;
    QMovie *mermaid;
    QMediaPlayer *victory_song;
    QTimer *EndSieg;
    QGraphicsView *creators;
    QGraphicsScene *scene;
    QGridLayout *centre;
    QWidget *p;
    QLabel *photo;
private slots:
    void advance(int phase);
    void Restart_Game();
    void Authors();
    void Game_over();
public slots:
    void set_name(QString a)
    {
        name_of_winner=a;
    }
};

#endif // VICTORY_H
