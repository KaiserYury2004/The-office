#include "victory.h"
#include"starter.h"
Victory::Victory(QWidget *parent,QString name,int number):QWidget{parent}
{

    p=parent;
    Winner=new QLabel(this);
    //    the_best=new QLabel("Лучший сотрудник",this);
    //    the_best->setGeometry(50,150,240,30);
    //    the_best->setFont(QFont("French Script MT", 14, QFont::Normal));
    //QPixmap frame("C:/Users/kaise/Pictures/пон.jpg");
    merm=new QLabel(this);
    photo=new QLabel(this);
    photo->setGeometry(290,157,95,95);
    victory_song=new QMediaPlayer(this);
    centre=new QGridLayout(this);
    victory_song->setMedia(QUrl::fromLocalFile("../Game/victory.mp3"));
    victory_song->setVolume(30);
    victory_song->setPosition(6000);
    victory_song->play();
    merm->setText("Я тут");
    merm->setGeometry(840,160,150,150);
    mermaid=new QMovie(this);
    mermaid->setFileName(":/Mermaid.gif");
    merm->setMovie(mermaid);
    mermaid->start();
    Winner->setGeometry(300,250,100,20);
    QString name_new_of_winner=name;
    Winner->setText(name_new_of_winner);
    Frame=new QLabel(this);
    The_end=new QPushButton(this);
    The_end->setGeometry(170,340,100,100);
    The_end->setStyleSheet("QPushButton{background: transparent;}");
    The_end->setText("");
    connect(The_end,&QPushButton::clicked,this,&Victory::Game_over);
    //connect(The_end,SIGNAL(clicked()),this,&MainWindow::close);
    About_creators=new QPushButton(this);
    About_creators->setGeometry(320,340,100,100);
    About_creators->setStyleSheet("QPushButton{background: transparent;}");
    About_creators->setText("");
    connect(About_creators,&QPushButton::clicked,this,&Victory::Authors);
    Restart=new QPushButton(this);
    Restart->setGeometry(35,340,100,100);
    Restart->setStyleSheet("QPushButton{background: transparent;}");
    Restart->setText("");
    connect(Restart,&QPushButton::clicked,this,&Victory::Restart_Game);
    QPalette pal;
    pal.setBrush(backgroundRole(), QBrush(QPixmap ("../Game/Victory_Screen.jpg")));
    setPalette(pal);
    setAutoFillBackground(true);
    setFixedSize(960,540);
    EndSieg=new QTimer(this);
    EndSieg->start(1000);
    switch (number)
    {
    case 0:
    photo->setPixmap(QPixmap("../Game/Yellow.png"));
        break;
    case 1:
photo->setPixmap(QPixmap("../Game/Red.png"));//треугольник
        break;
    case 2:
    photo->setPixmap(QPixmap("../Game/Blue.png"));//треугольник
        break;
    case 3:
    photo->setPixmap(QPixmap("../GameGreen.png"));//треугольник
        break;
    }
    show();
    //    QGraphicsScene scene;
    //    scene.addText("Hello, world!");
    //    QGraphicsView view(&scene);
    //    view.show();
}
void Victory::advance(int phase)
{
    if(phase)
    {
        mermaid->stop();
        merm->hide();
        Winner->setText("Все остальные были уволены");
    }
}
void Victory::Game_over()
{
    p->close();
    victory_song->stop();
    close();
}
void Victory::Authors()
{
    subs *s=new subs(nullptr);
    s->show();
}
void Victory::Restart_Game()
{
    p->close();
    Starter *str=new Starter(nullptr);
    QPalette pal;
    pal.setBrush(str->backgroundRole(), QBrush(QPixmap (":/Start screen.jpg")));
    str->setPalette(pal);
    str->setAutoFillBackground(true);
    str->setFixedSize(960,540);
    str->show();
    victory_song->stop();
    close();
}
