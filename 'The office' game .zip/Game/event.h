#ifndef EVENT_H
#define EVENT_H
#include <QString>
#include <QPixmap>
enum Action{Roll_the_dice, Skip, Go_forward, Go_Back, Dismissal, Choise};
class Event
{
public:
    explicit Event();
    Event(QString, int, Action, int, Action _choise1 = Dismissal, Action _choise2 = Dismissal);
    Event(const Event&);
    Event& operator=(const Event&);
    int GetCell_num();
    Action GetAct();
    int GetCount();
    QString GetText();
    Action GetChoise1();
    Action GetChoise2();
private:
    QString text;
    int cell_num;
    Action act;
    int count;
    Action choise1;
    Action choise2;
};
#endif // EVENT_H
