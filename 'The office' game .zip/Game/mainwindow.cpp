#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QLabel>
#include<QGridLayout>
#include<QPushButton>
#include<QTimer>
#include<QTime>
#include <ctime>
#include "event.h"
#include<victory.h>
#include<QKeyEvent>
QString hod="◯△□☆";//1-☆   2-□    3-△   4-○
int hod1=3;
MainWindow::MainWindow(QWidget *parent,int counter )
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    l1=new QLabel();
    l2=new QLabel();
    l3=new QLabel();
    l4=new QLabel();
    l5=new QLabel();
    l6=new QLabel();
    l7=new QLabel();
    l8=new QLabel();
    l9=new QLabel();
    l10=new QLabel();
    l11=new QLabel();
    l12=new QLabel();
    l13=new QLabel();
    l14=new QLabel();
    l15=new QLabel();
    ac1=new QMovie(this);
    ac2=new QMovie(this);
    ac3=new QMovie(this);
    ac4=new QMovie(this);
    ac5=new QMovie(this);
    ac6=new QMovie(this);
    ac7=new QMovie(this);
    ac8=new QMovie(this);
    ac9=new QMovie(this);
    ac10=new QMovie(this);
    ac11=new QMovie(this);
    ac12=new QMovie(this);
    ac13=new QMovie(this);
    ac14=new QMovie(this);
    ac15=new QMovie(this);



    d1=new QDialog();

    ac1->setFileName(":/2.gif");
    l1->setMovie(ac1);
    ac1->start();
    l1->setParent(d1);
    l1->setGeometry(0,0,500,500);
    QPushButton *b1=new QPushButton("");
    b1->setGeometry(150,449,190,40);
    b1->setStyleSheet(        "QPushButton{background: transparent;}"        );
    connect(b1,SIGNAL(clicked()),this,SLOT(kubik()));
    b1->setParent(d1);

    d2=new QDialog();

    ac2->setFileName(":/4.gif");
    l2->setMovie(ac2);
    ac2->start();
    l2->setParent(d2);
    l2->setGeometry(0,0,500,500);
    QPushButton *b2=new QPushButton("");
    b2->setGeometry(220,380,240,70);
    b2->setStyleSheet(        "QPushButton{background: transparent;}"        );
    connect(b2,SIGNAL(clicked()),this,SLOT(skip()));
    b2->setParent(d2);

    d3=new QDialog();
    ac3->setFileName(":/6.gif");
    l3->setMovie(ac3);
    ac3->start();
    l3->setParent(d3);
    l3->setGeometry(0,0,500,500);
    QPushButton *b3=new QPushButton("");
    QPushButton* b31=new QPushButton("");
    b31->setParent(d3);
    b3->setParent(d3);
    b3->setGeometry(34,175,180,43);
    b3->setStyleSheet(        "QPushButton{background: transparent;}"        );
    b31->setGeometry(299,175,180,43);
    b31->setStyleSheet(        "QPushButton{background: transparent;}"        );
    connect(b3,SIGNAL(clicked()),this,SLOT(go_1()));
    connect(b31,SIGNAL(clicked()),this,SLOT(skip()));


    d4=new QDialog();
    ac4->setFileName(":/8.gif");
    l4->setMovie(ac4);
    ac4->start();
    l4->setParent(d4);
    l4->setGeometry(0,0,500,500);
    QPushButton *b4=new QPushButton("");
    b4->setGeometry(0,363,158,120);
    b4->setStyleSheet(        "QPushButton{background: transparent;}"        );
    connect(b4,SIGNAL(clicked()),this,SLOT(go_3()));
    b4->setParent(d4);
    d5=new QDialog();
    ac5->setFileName(":/10.gif");
    l5->setMovie(ac5);
    ac5->start();
    QPushButton* b51=new QPushButton("2");
    l5->setParent(d5);
    b51->setParent(d5);
    b51->setGeometry(356,176,130,93);
    b51->setStyleSheet(        "QPushButton{background: transparent;}"        );
    QPushButton *b5=new QPushButton("1");
    b5->setParent(d5);
    l5->setGeometry(0,0,500,500);
    b5->setGeometry(199,176,130,93);
    b5->setStyleSheet(        "QPushButton{background: transparent;}"        );
    connect(b5,SIGNAL(clicked()),this,SLOT(skip()));
    connect(b51,SIGNAL(clicked()),this,SLOT(go__1()));


    d6=new QDialog();
    ac6->setFileName(":/13.gif");
    l6->setMovie(ac6);
    ac6->start();
    l6->setParent(d6);
    l6->setGeometry(0,0,500,500);
    QPushButton *b6=new QPushButton("");
    connect(b6,SIGNAL(clicked()),this,SLOT(go_end()));
    b6->setParent(d6);
    b6->setGeometry(394,280,102,122);
    b6->setStyleSheet(        "QPushButton{background: transparent;}"        );


    d7=new QDialog();
    ac7->setFileName(":/15.gif");
    l7->setMovie(ac7);
    ac7->start();
    l7->setParent(d7);
    l7->setGeometry(0,0,500,500);
    QPushButton *b7=new QPushButton("");
    connect(b7,SIGNAL(clicked()),this,SLOT(kubik()));
    b7->setParent(d7);
    b7->setGeometry(140,72,113,113);
    b7->setStyleSheet(        "QPushButton{background: transparent;}"        );

    d8=new QDialog();
    ac8->setFileName(":/19.gif");
    l8->setMovie(ac8);
    ac8->start();
    l8->setParent(d8);
    l8->setGeometry(0,0,500,500);
    QPushButton *b8=new QPushButton("");
    connect(b8,SIGNAL(clicked()),this,SLOT(proverka()));
    b8->setParent(d8);
    b8->setGeometry(275,232,158,63);
    b8->setStyleSheet(        "QPushButton{background: transparent;}"        );

    d9=new QDialog();
    ac9->setFileName(":/17.gif");
    l9->setMovie(ac9);
    ac9->start();
    l9->setParent(d9);
    l9->setGeometry(0,0,500,500);
    QPushButton* b91=new QPushButton("");
    QPushButton *b9=new QPushButton("");
    connect(b91,SIGNAL(clicked()),this,SLOT(go_1()));
    b91->setParent(d9);
    connect(b9,SIGNAL(clicked()),this,SLOT(skip()));
    b9->setParent(d9);
    b9->setGeometry(326,277,158,40);
    b9->setStyleSheet(        "QPushButton{background: transparent;}"        );
    b91->setGeometry(304,331,147,38);
    b91->setStyleSheet(        "QPushButton{background: transparent;}"        );
    d10=new QDialog();
    ac10->setFileName(":/22.gif");
    l10->setMovie(ac10);
    ac10->start();
    l10->setParent(d10);
    l10->setGeometry(0,0,500,500);
    QPushButton* b101=new QPushButton("2");
    b101->setParent(d10);
    connect(b101,SIGNAL(clicked()),this,SLOT(go__4()));
    QPushButton *b10=new QPushButton("Пон");
    connect(b10,SIGNAL(clicked()),this,SLOT(go__6()));
    b10->setParent(d10);
    b10->setGeometry(337,63,129,59);
    b10->setStyleSheet(        "QPushButton{background: transparent;}"        );
    b101->setGeometry(337,150,138,59);
    b101->setStyleSheet(        "QPushButton{background: transparent;}"        );


    d11=new QDialog();
    ac11->setFileName(":/25.gif");
    l11->setMovie(ac11);
    ac11->start();
    l11->setParent(d11);
    l11->setGeometry(0,0,500,500);
    QPushButton *b11=new QPushButton("");
    connect(b11,SIGNAL(clicked()),this,SLOT(go__5()));
    b11->setParent(d11);
    b11->setGeometry(11,7,204,46);
    b11->setStyleSheet(        "QPushButton{background: transparent;}"        );



    d12=new QDialog();
    ac12->setFileName(":/30.gif");
    l12->setMovie(ac12);
    ac12->start();
    l12->setParent(d12);
    l12->setGeometry(0,0,500,500);
    QPushButton *b12=new QPushButton("");
    connect(b12,SIGNAL(clicked()),this,SLOT(go_end()));
    b12->setParent(d12);
    b12->setGeometry(250,28,240,62);
    b12->setStyleSheet(        "QPushButton{background: transparent;}"        );

    d13=new QDialog();
    ac13->setFileName(":/27.gif");
    l13->setMovie(ac13);
    ac13->start();
    l13->setParent(d13);
    l13->setGeometry(0,0,500,500);
    QPushButton* b131=new QPushButton("");
    b131->setParent(d13);
    QPushButton *b13=new QPushButton("");
    connect(b13,SIGNAL(clicked()),this,SLOT(skip()));
    connect(b131,SIGNAL(clicked()),this,SLOT(go_start()));
    b13->setParent(d13);
    b13->setGeometry(152,169,135,62);
    b13->setStyleSheet(        "QPushButton{background: transparent;}"        );
    b131->setGeometry(217,243,135,63);
    b131->setStyleSheet(        "QPushButton{background: transparent;}"        );


    d14=new QDialog();
    ac14->setFileName(":/32.gif");
    l14->setMovie(ac14);
    ac14->start();
    l14->setParent(d14);
    l14->setGeometry(0,0,500,500);
    QPushButton *b14=new QPushButton("");
    connect(b14,SIGNAL(clicked()),this,SLOT(skip()));
    b14->setParent(d14);
    b14->setGeometry(165,435,174,51);
    b14->setStyleSheet(        "QPushButton{background: transparent;}"        );


    d15=new QDialog();
    ac15->setFileName(":/34.gif");
    l15->setMovie(ac15);
    ac15->start();
    l15->setParent(d15);
    l15->setGeometry(0,0,500,500);
    QPushButton *b15=new QPushButton("");
    connect(b15,SIGNAL(clicked()),this,SLOT(skip()));
    b15->setParent(d15);
    b15->setGeometry(100,45,169,55);
    b15->setStyleSheet(        "QPushButton{background: transparent;}"        );



    d1->setFixedSize(500,500);
    d2->setFixedSize(500,500);
    d3->setFixedSize(500,500);
    d4->setFixedSize(500,500);
    d5->setFixedSize(500,500);
    d6->setFixedSize(500,500);
    d7->setFixedSize(500,500);
    d8->setFixedSize(500,500);
    d9->setFixedSize(500,500);
    d10->setFixedSize(500,500);
    d11->setFixedSize(500,500);
    d12->setFixedSize(500,500);
    d13->setFixedSize(500,500);
    d14->setFixedSize(500,500);
    d15->setFixedSize(500,500);
    ui->setupUi(this);
    setFixedSize(1920,1080);
    mp3_player=new QMediaPlayer(this);
    mp3_player->setMedia(QUrl::fromLocalFile("../Game/музыка игрового поля.mp3"));
    mp3_player->setVolume(20);
    mp3_player->play();
    layout=new QGridLayout(this);

    this->counter=counter;//кол-во игроков
    //this->number_of_player=number_of_player;//массив позиций игроков
    number_of_player=1;//начинаем с 1-ого игрока
    QPixmap bkngd(":/Игровое поле.png");
    bkngd=bkngd.scaled(this->size(), Qt::IgnoreAspectRatio);
    QPalette pal1;
    pal1.setBrush(QPalette::Window, bkngd);
    this->setPalette(pal1);
    QLabel *field[35];
    field[0]=ui->label;
    dice_info=new QLabel(this);
    dice_info->setGeometry(100,500,100,60);
    dice_info->setText("Текст");
    ui->label->setGeometry(1060, 930, 70, 70);

    ui->label_turn->setGeometry(825,300,100,60);
    //ui->label_turn->setText(QString::);
    field[1]=ui->label_2;
    ui->label_2->setGeometry(1000, 730, 70, 70);

    field[2]=ui->label_3;
    ui->label_3->setGeometry(790, 730, 70, 70);

    field[3]=ui->label_4;
    ui->label_4->setGeometry(575, 700, 70, 70);

    field[4]=ui->label_5;
    ui->label_5->setGeometry(475, 840, 70, 70);

    field[5]=ui->label_6;
    ui->label_6->setGeometry(320, 910, 70, 70);

    field[6]=ui->label_7;
    ui->label_7->setGeometry(135, 880, 70, 70);

    field[7]=ui->label_8;
    ui->label_8->setGeometry(65, 750, 70, 70);

    field[8]=ui->label_9;
    ui->label_9->setGeometry(60, 550, 70, 70);

    field[9]=ui->label_10;
    ui->label_10->setGeometry(200, 420, 70, 70);

    field[10]=ui->label_11;
    ui->label_11->setGeometry(100, 280, 70, 70);

    field[11]=ui->label_12;
    ui->label_12->setGeometry(80, 130, 70, 70);

    field[12]=ui->label_13;
    ui->label_13->setGeometry(60, 10, 70, 70);

    field[13]=ui->label_14;
    ui->label_14->setGeometry(220, 30, 70, 70);

    field[14]=ui->label_15;
    ui->label_15->setGeometry(435, 160, 70, 70);

    field[15]=ui->label_16;
    ui->label_16->setGeometry(360, 320, 70, 70);

    field[16]=ui->label_17;
    ui->label_17->setGeometry(520, 400, 70, 70);

    field[17]=ui->label_18;
    ui->label_18->setGeometry(590, 230, 70, 70);

    field[18]=ui->label_19;
    ui->label_19->setGeometry(725, 50, 70, 70);

    field[19]=ui->label_20;
    ui->label_20->setGeometry(900, 130, 70, 70);

    field[20]=ui->label_21;
    ui->label_21->setGeometry(1110, 30, 70, 70);

    field[21]=ui->label_22;
    ui->label_22->setGeometry(1330, 140, 70, 70);

    field[22]=ui->label_23;
    ui->label_23->setGeometry(1500, 60, 70, 70);

    field[23]=ui->label_24;
    ui->label_24->setGeometry(1700, 80, 70, 70);

    field[24]=ui->label_25;
    ui->label_25->setGeometry(1790, 200, 70, 70);

    field[25]=ui->label_26;
    ui->label_26->setGeometry(1790, 370, 70, 70);

    field[26]=ui->label_27;
    ui->label_27->setGeometry(1600, 400, 70, 70);

    field[27]=ui->label_28;
    ui->label_28->setGeometry(1420, 330, 70, 70);

    field[28]=ui->label_29;
    ui->label_29->setGeometry(1300, 460, 70, 70);

    field[29]=ui->label_30;
    ui->label_30->setGeometry(1400, 630, 70, 70);

    field[30]=ui->label_31;
    ui->label_31->setGeometry(1600, 610, 70, 70);

    field[31]=ui->label_32;
    ui->label_32->setGeometry(1800, 670, 70, 70);

    field[32]=ui->label_33;
    ui->label_33->setGeometry(1750, 835, 70, 70);

    field[33]=ui->label_34;
    ui->label_34->setGeometry(1630, 945, 70, 70);
    field[34]=ui->label_36;
    ui->label_36->setGeometry(1460, 980, 70, 70);

    field[34]->setText("Финиш");
    for(int i=0; i<35; i++)
    {

        field[i]->setText("");
        field[i]->setStyleSheet("background-color:white;"
                                "font:bold 22px");

    }
    //◯△□☆
    switch(counter)
    {


    case 1:
        ui->label->setText("◯△");
        break;
    case 2:
        ui->label->setText("◯△");
        break;
    case 3:
        ui->label->setText("◯△□");
        break;
        //
    case 4:
        ui->label->setText("◯△□☆");
        break;
    }
    ui->label_player1->setGeometry(740,820,120,100);
    ui->label_player2->setGeometry(740,865,120,100);
    ui->label_player3->setGeometry(740,910,120,100);
    ui->label_player4->setGeometry(740,965,120,100);
    ui->label_player1->setStyleSheet("font:bold 20px");
    ui->label_player2->setStyleSheet("font:bold 20px");
    ui->label_player3->setStyleSheet("font:bold 20px");
    ui->label_player4->setStyleSheet("font:bold 20px");
    layout->addWidget(ui->label,0,1);
    layout->addWidget(ui->label_2,0,2);
    layout->addWidget(ui->label_3,0,3);
    layout->addWidget(ui->label_4,0,4);
    layout->addWidget(ui->label_5,0,5);
    layout->addWidget(ui->label_6,0,6);
    layout->addWidget(ui->label_7,0,7);
    layout->addWidget(ui->label_8,1,7);
    layout->addWidget(ui->label_9,1,6);
    layout->addWidget(ui->label_10,1,5);
    layout->addWidget(ui->label_11,1,4);
    layout->addWidget(ui->label_12,1,3);
    layout->addWidget(ui->label_13,1,2);
    layout->addWidget(ui->label_14,1,1);
    layout->addWidget(ui->label_15,2,1);
    layout->addWidget(ui->label_16,2,2);
    layout->addWidget(ui->label_17,2,3);
    layout->addWidget(ui->label_18,2,4);
    layout->addWidget(ui->label_19,2,5);
    layout->addWidget(ui->label_20,2,6);
    layout->addWidget(ui->label_21,2,7);
    layout->addWidget(ui->label_22,3,7);
    layout->addWidget(ui->label_23,3,6);
    layout->addWidget(ui->label_24,3,5);
    layout->addWidget(ui->label_25,3,4);
    layout->addWidget(ui->label_26,3,3);
    layout->addWidget(ui->label_27,3,2);
    layout->addWidget(ui->label_28,3,1);
    layout->addWidget(ui->label_29,4,1);
    layout->addWidget(ui->label_30,4,2);
    layout->addWidget(ui->label_31,4,3);
    layout->addWidget(ui->label_32,4,4);
    layout->addWidget(ui->label_33,4,5);
    layout->addWidget(ui->label_34,4,6);
    layout->addWidget(ui->label_36,4,7);
    /*for(int i=0;i<7;i++)
    {
        if(i%2==0)
        {
            for(int j=0;j<5;j++)
            {
                QLabel *lab=new QLabel("step"+QString::number((7-i)*5-j));
                lab->setFixedSize(80,60);
                layout->addWidget(lab,i,j);
                lab->setProperty("i",i);
                lab->setProperty("j",j);
                lab->setProperty("step",(7-i)*5-j);
            }
        }
        else
        {
            for(int j=0;j<5;j++)
            {
                QLabel *lab=new QLabel("step"+QString::number((6-i)*5+j + 1));
                lab->setFixedSize(80,60);
                layout->addWidget(lab,i,j);
                lab->setProperty("i",i);
                lab->setProperty("j",j);
                lab->setProperty("step",(6-i)*5+j + 1);
            }
        }
    }
    int playing_field[35];
    for(int i=0;i<35;i++)
    {
        playing_field[i]=0;
    }*/
    //layout->setAlignment(Qt::AlignCenter |Qt::AlignRight);
    //layout->setVerticalSpacing(80);
    //layout->setHorizontalSpacing(80);
    //QWidget *w=new QWidget(this);
    //QLabel *turn=new QLabel;
    //ui->label_turn->setText("Игрок\n"+name_of_player[hod1]+"\nначинайте");
    ui->tableWidget->setEnabled(false);
    for(int i = 0; i < 4; i++) { // заполнение первого столбца 1-☆   2-□    3-△   4-○
        QTableWidgetItem *item = new QTableWidgetItem;
        QString s(hod[i]);
        item->setText(s);
        ui->tableWidget->setItem(i,0, item);
    }

    for(int i = 0; i < counter; i++) { // заполнение второго столбца с позицией
        QTableWidgetItem *item = new QTableWidgetItem;
        item->setText("0");
        ui->tableWidget->setItem(i,1, item);
    }

    for(int i = 0; i < counter; i++) { // заполнение 3 столбца
        QTableWidgetItem *item = new QTableWidgetItem;
        item->setText("В офисе");
        ui->tableWidget->setItem(i,2, item);
    }
    srand(time(NULL));
    for(int i = counter; i < 4; i++) { // заполнение ???
        int random=rand()%4;
        for (int j = 1; j < 3; j++) {
            QTableWidgetItem *item = new QTableWidgetItem;
            if(j == 2) {
                if(random==0)
                {
                    item->setText("Уволен");
                }
                if(random==1)
                {
                    item->setText("В отпуске");
                }
                if(random==2)
                {
                    item->setText("Перекур");
                }
                if(random==3)
                {
                    item->setText("Больничный");
                }
            }
            else {
                if(random==0)
                {
                    item->setText("На улице");
                }
                if(random==1)
                {
                    item->setText("На море");
                }
                if(random==2)
                {
                    item->setText("На курилке");
                }
                if(random==3)
                {
                    item->setText("Дома");
                }
            }
            ui->tableWidget->setItem(i, j, item);
        }
    }

    layout->addWidget(ui->tableWidget,0,0);

    // w->setLayout(layout);
    // setCentralWidget(w);
    dice_button=new QPushButton(this);
    dice_button->setGeometry(100,600,100,60);
    dice_button->setText("Бросить кубик");
    dice_info->setText("Начинаем игру");
    connect(dice_button,&QPushButton::clicked,this,&MainWindow::Dice_button_clicked);
    QLabel *transition=new QLabel;
    transition->setText("Transition");
    //events[2] = Event("Cегодняшний день начался просто прекрасно - вам улыбнулся босс! бросьте кубик ещё раз", 2, Roll_the_dice, 1);
    //events[4] = Event(" о нет! Кажется кто-то из коллег решил подшутить над вами и заклеить всё ваше рабочее пространство стикерами, пропустите ход, чтобы убрать это безобразие", 4, Skip, 1);
    //events[6] = Event("Вам предлагают поработать свехрурочно, но сегодня день рождения вашей жены. Пройдите на 1 клетку вперёд, но вероятность вашего увольнения увеличиться или пропустите следующий ход", 6, Choise, 1, Go_forward, Skip);
    //events[8] = Event("Поели - можно и ударно поработать! передвиньте фишку на 3 клетки вперёд", 8, Go_forward, 3);
    //events[10] = Event("Босс поручил тебе позаботиться о стажёре компании. У тебя есть выбор: пропусти свой следующий ход, но позже начни его с преимуществом в 1 клетку или откажись от стажёра и вернись на 1 клетку назад", 10, Choise, 1);
    //events[13] = Event("Увольнение! пакуйте свои вещи по коробкам, ваш путь был недолгим в этом офисе, но вас запомнят как дествительно добросовестного сотрудника (о вас забудут уже завтра, а замену вам нашли ещё в прошлый вторник)", 13, Dismissal, 1);
    //events[15] = Event("вы попили вкуснейшего кофе за счёт компании, у вас прилив сил и энергии, сделайте дополнительный бросок!", 15, Roll_the_dice, 1);
    //events[17] = Event("отчёт не готов, надо остаться поработать до ночи (в следующем ходу у вас отнимается 3 очка хода, если выпало меньше 3, сделайте ход назад на соответствующее количество клеток", 17, Choise, 3);
    //events[19] = Event("сегодня двери офиса оказались закрыты. Возможно, сегодня выходной? Но вы об этом не знали? Как поступите? Уйдёте и насладитесь отдыхом в кругу своей семьи или подождёте, когда кто-то придёт? Подожду (вы целый день просидели под дверьми офиса и потратили день впустую), пойду отдохну(вы хорошо провели время, что придало вам сил, перейдите на 1 клетку вперёд) ", 19, Choise, 1, Choise, Go_forward);
    //events[22] = Event("клиент оказался недоволен работой компании и агрессивно высказывает своё недовольство. Как поступите? Попытаетесь решить вопрос мирно, если клиент ни в какую не соглашается на новые условия, то позовёте начальника, который принесёт извинения заказчику (вопрос будет урегулирован, но начальник будет зол на вас; 6 клеток назад) или начнёте агрессировать в ответ (4 клетки назад - выговор от компании за неподобающее поведение + 2 пропуска хода - восстанавливаетесь после дракт)", 22, Choise, 6, Go_Back, Go_Back);
    //events[25] = Event("кофе-брейк с коллегами затянулся и чтобы не упасть в грязь лицом вы решили купить кофе за собственнные деньги. Вернитесь на 5 клеток назад", 25, Go_Back, 5);
    //events[27] = Event(" перекус, к сожалению, был некачественным и тебя вырвало на документы. Что ж, пора начинать сначала, вернись на старт", 27, Go_Back, 69);
    //events[30] = Event("внезапно друг, с которым вы постоянно оставались на сверхурочную работу, не пришёл на работу из-за выгорания . Что выберете? Сходить поддержать друга (пропуск хода) или поработать свехрурочно без него (перейдите на клетку 34) ", 30, Choise, 69, Skip, Go_forward);
    //events[32] = Event("месяц подходит к концу, а значит пора наводить порядок в документах! Вы были почётно выбраны для этого дела, пропустите один ход, чтобы сделать эдту работу качественно", 32, Skip, 1);
    //events[34] = Event("вы перетрудились... нет, правда. у вас обморок и вы лежите в больнице. пропустите 2 хода", 34, Skip, 2);
    d1->setWindowFlags(Qt::WindowStaysOnTopHint);
    d2->setWindowFlags(Qt::WindowStaysOnTopHint);
    d3->setWindowFlags(Qt::WindowStaysOnTopHint);
    d4->setWindowFlags(Qt::WindowStaysOnTopHint);
    d5->setWindowFlags(Qt::WindowStaysOnTopHint);
    d6->setWindowFlags(Qt::WindowStaysOnTopHint);
    d7->setWindowFlags(Qt::WindowStaysOnTopHint);
    d8->setWindowFlags(Qt::WindowStaysOnTopHint);
    d9->setWindowFlags(Qt::WindowStaysOnTopHint);
    d10->setWindowFlags(Qt::WindowStaysOnTopHint);
    d11->setWindowFlags(Qt::WindowStaysOnTopHint);
    d12->setWindowFlags(Qt::WindowStaysOnTopHint);
    d13->setWindowFlags(Qt::WindowStaysOnTopHint);
    d14->setWindowFlags(Qt::WindowStaysOnTopHint);
    d15->setWindowFlags(Qt::WindowStaysOnTopHint);
    dice_info->setGeometry(722,414,241,20);
    dice_info->setAlignment(Qt::AlignCenter);

    ui->label->setAlignment(Qt::AlignCenter);
    ui->label_10->setAlignment(Qt::AlignCenter);
    ui->label_11->setAlignment(Qt::AlignCenter);
    ui->label_12->setAlignment(Qt::AlignCenter);
    ui->label_13->setAlignment(Qt::AlignCenter);
    ui->label_14->setAlignment(Qt::AlignCenter);
    ui->label_15->setAlignment(Qt::AlignCenter);
    ui->label_16->setAlignment(Qt::AlignCenter);
    ui->label_17->setAlignment(Qt::AlignCenter);
    ui->label_18->setAlignment(Qt::AlignCenter);
    ui->label_19->setAlignment(Qt::AlignCenter);
    ui->label_20->setAlignment(Qt::AlignCenter);
    ui->label_21->setAlignment(Qt::AlignCenter);
    ui->label_22->setAlignment(Qt::AlignCenter);
    ui->label_23->setAlignment(Qt::AlignCenter);
    ui->label_24->setAlignment(Qt::AlignCenter);
    ui->label_25->setAlignment(Qt::AlignCenter);
    ui->label_26->setAlignment(Qt::AlignCenter);
    ui->label_27->setAlignment(Qt::AlignCenter);
    ui->label_28->setAlignment(Qt::AlignCenter);
    ui->label_29->setAlignment(Qt::AlignCenter);
    ui->label_30->setAlignment(Qt::AlignCenter);
    ui->label_31->setAlignment(Qt::AlignCenter);
    ui->label_32->setAlignment(Qt::AlignCenter);
    ui->label_33->setAlignment(Qt::AlignCenter);
    ui->label_34->setAlignment(Qt::AlignCenter);
    ui->label_2->setAlignment(Qt::AlignCenter);
    ui->label_3->setAlignment(Qt::AlignCenter);
    ui->label_4->setAlignment(Qt::AlignCenter);
    ui->label_5->setAlignment(Qt::AlignCenter);
    ui->label_6->setAlignment(Qt::AlignCenter);
    ui->label_7->setAlignment(Qt::AlignCenter);
    ui->label_8->setAlignment(Qt::AlignCenter);
    ui->label_9->setAlignment(Qt::AlignCenter);
    ui->label_10->setAlignment(Qt::AlignCenter);
    //ui->label_36->setGeometry(722,319,241,20);
    //ui->label_36->setStyleSheet("background-color: rgba(255, 85, 127, 80");
    ui->label_36->setAlignment(Qt::AlignCenter);
    //QVector<QString>::iterator it=names.begin();
    //kto_hodit->setText("Ходит "+*it);
    ui->label_36->setText(" ");
    dice_button->setStyleSheet(        "QPushButton{background: transparent;}"        );
    dice_button->setGeometry(722,585,241,60);
}
void MainWindow::skip()
{
    dice_button->setEnabled(true);
    if(list_of_moves[hod1]==10)
    {
        go(1);
    }
    list_of_skips[hod1]++;
    if(list_of_moves[hod1]==34)
        list_of_skips[hod1]++;
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
}
void MainWindow::kubik()
{
    dice_button->setEnabled(true);
    hod1=(hod1+counter-1)%counter;
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
}


void MainWindow::go(int a)
{
    dice_button->setEnabled(true);
    QString s=((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text();
    list_of_moves[hod1]+=a;
    QString s1;
    int k=0;

    for(int i=0;i<s.size();i++)
    {
        if(s[i]==hod[hod1])
            continue;
        s1[k]=s[i];
        k++;
    }
    ((QLabel*)layout->itemAt(list_of_moves[hod1]-a)->widget())->setText(s1);
    QChar c=hod[hod1];
    ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(c+((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text());
    QTableWidgetItem *item = new QTableWidgetItem; // изменение позиции в таблице
    item->setText(QString::number(list_of_moves[hod1]+1));
    ui->tableWidget->setItem(hod1,1, item);
    if(list_of_moves[hod1]+1==19)
    {
        list_of_skips[hod1]++;
    }
    if(list_of_moves[hod1]+1==22||list_of_moves[hod1]==33)
    {
        list_of_skips[hod1]+=2;
    }
}

void MainWindow::go_3()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(3);
}

void MainWindow::go_start()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    int a=33-list_of_moves[hod1];
    go(a);
}
void MainWindow::go_end()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    int a=list_of_moves[hod1]*(-1);
    go(a);
}
void MainWindow::go__5()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(-5);
}
void MainWindow::go_1()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(1);
}
void MainWindow::go__1()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(-1);
}

void MainWindow::go__4()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(-4);
}

void MainWindow::go__6()
{
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    go(-6);
}


void MainWindow::proverka()
{
    dice_button->setEnabled(true);
    QPushButton *asd=(QPushButton*)sender();
    asd->parentWidget()->close();
    int a=rand()%6+1;
    dice_info->setText(QString::number(a));
    if(a<4)
    {
        dice_info->setText("Увы,но вы идёте назад(((");
        a*=-1;
        go(a);
    }
}

void MainWindow::set_tabl_names()
{
    QStringList s;
    s<<name1<<name2<<name3<<name4;
    name_of_player[0]=name1;
    names.push_back(name1);
    if(name2!="Player2")
    {
        names.push_back(name2);
        name_of_player[1]=name2;
        if(name3!="Player3")
        {
            names.push_back(name3);
            name_of_player[2]=name3;
            if(name4!="Player4")
            {
                names.push_back(name4);
                name_of_player[3]=name4;
            }
        }
    }
    switch (counter) {
    case 1:
        ui->label_player1->setText(name1);
        ui->label_player2->setText("Компьютер");
        break;
    case 2:
        ui->label_player1->setText(name1);
        ui->label_player2->setText(name2);
        break;
    case 3:
        ui->label_player1->setText(name1);
        ui->label_player2->setText(name2);
        ui->label_player3->setText(name3);
        break;
    case 4:
        ui->label_player1->setText(name1);
        ui->label_player2->setText(name2);
        ui->label_player3->setText(name3);
        ui->label_player4->setText(name4);
        break;
    }
    ui->tableWidget->setVerticalHeaderLabels(s);
    ui->tableWidget->hide();
}
//ход чей-то =ход%каунтер +1; не так    чей-то ход +1 %каунтер
void MainWindow::Dice_button_clicked()
{
    hod1++;
    hod1=hod1%counter;
    if(list_of_skips[hod1]==0)
    {
        //        while(list_of_skips[hod1] > 0) {
        //            list_of_skips[hod1]--;
        //            hod1++;
        //            hod1=hod1%counter;
        //        }
        int number = rand()%6+1;
        QChar c=hod[hod1];
        QString s1;
        int k=0;
        QString s=((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text();
        for(int i=0;i<s.size();i++)
        {
            if(s[i]==hod[hod1])
                continue;
            s1[k]=s[i];
            k++;
        }
        ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(s1);
        list_of_moves[hod1]+=number;
        if(list_of_moves[hod1]<34)
        {
            ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(c+((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text());
            QTableWidgetItem *item = new QTableWidgetItem; // изменение позиции в таблице
            item->setText(QString::number(list_of_moves[hod1]+1));

            ui->tableWidget->setItem(hod1,1, item);
        }
        else
        {
            ((QLabel*)layout->itemAt(34)->widget())->setText(name_of_player[hod1]);
            QPushButton *b=(QPushButton*)sender();
            b->setEnabled(false);
            QTableWidgetItem *item = new QTableWidgetItem;
            Victory winner=new Victory(this,name_of_player[hod1],hod1);
            item->setText("35");
            ui->tableWidget->setItem(hod1,1, item);
            mp3_player->stop();
        }
        dice_info->setText(QString::number(number));
        dice_info->setStyleSheet("font:bold 20px");
        //ui->label_turn->setText(name_of_player[hod1+1]);
        //if(events[i].GetCell_num() == list_of_moves[hod1]) {}
        switch (list_of_moves[hod1]+1) {
        case 2:
            d1->show();
            dice_button->setEnabled(false);
            break;
        case 4:
            d2->show();
            dice_button->setEnabled(false);
            break;
        case 6:
            d3->show();
            dice_button->setEnabled(false);
            break;
        case 8:
            d4->show();
            dice_button->setEnabled(false);
            break;
        case 10:
            d5->show();
            dice_button->setEnabled(false);
            break;
        case 13:
            d6->show();
            dice_button->setEnabled(false);
            break;
        case 15:
            d7->show();
            dice_button->setEnabled(false);
            break;
        case 17:
            d8->show();
            dice_button->setEnabled(false);
            break;
        case 19:
            d9->show();
            break;
        case 22:
            d10->show();
            dice_button->setEnabled(false);
            break;
        case 25:
            d11->show();
            dice_button->setEnabled(false);
            break;
        case 27:
            d12->show();
            dice_button->setEnabled(false);
            break;
        case 30:
            d13->show();
            dice_button->setEnabled(false);
            break;
        case 32:
            d14->show();
            dice_button->setEnabled(false);
            break;
        case 34:
            d15->show();
            dice_button->setEnabled(false);
            break;
        default:
            break;
        }
        //QVector<QString>::iterator it=names.begin()+hod1;
        //kto_hodit->setText("Ходит "+*it);
    }
    else
    {
        list_of_skips[hod1]--;
    }
    //if(counter==1)
    //{
    //robot();
    //}
}
void MainWindow::kubik_t()
{
    dice_button->setEnabled(true);
    if(t1->interval()!=0)
    {
        t1->stop();
        d1->close();
    }
    if(t7->interval()!=0)
    {
        t7->stop();
        d7->close();
    }
    int num=rand()%6+1;
    list_of_moves[hod1]+=num;
    dice_info->setText(QString::number(num));
    QChar c=hod[hod1];
    QString s1;
    int k=0;
    QString s=((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text();
    for(int i=0;i<s.size();i++)
    {
        if(s[i]==hod[hod1])
            continue;
        s1[k]=s[i];
        k++;
    }
    ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(s1);
    list_of_moves[hod1]+=num;
    if(list_of_moves[hod1]<34)
    {
        ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(c+((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text());
        QTableWidgetItem *item = new QTableWidgetItem; // изменение позиции в таблице
        item->setText(QString::number(list_of_moves[hod1]+1));
        ui->tableWidget->setItem(hod1,1, item);
    }
    else
    {
        ((QLabel*)layout->itemAt(34)->widget())->setText(name_of_player[hod1]+ "победил");
        QPushButton *b=(QPushButton*)sender();
        b->setEnabled(false);
        QTableWidgetItem *item = new QTableWidgetItem;
        Victory winner=new Victory(this,name_of_player[hod1],hod1);
        item->setText("35");
        ui->tableWidget->setItem(hod1,1, item);
        mp3_player->stop();
    }
    //ui->label_turn->setText(name_of_player[hod1]);
    //dice_info->setText("Text");
}
void MainWindow::skip_t()
{
    dice_button->setEnabled(true);
    if(list_of_moves[hod1]==10)
    {
        go(1);
    }
    list_of_skips[hod1]++;
    if(list_of_moves[hod1]==34)
        list_of_skips[hod1]++;
    if(t2->interval()!=0)
    {
        d2->close();
        t2->stop();
    }
    if(t14->interval()!=0)
    {
        d14->close();
        t14->stop();
    }
    if(t15->interval()!=0)
    {
        d15->close();
        t15->stop();
    }
    if(t3->interval()!=0)
    {
        d3->close();
        t3->stop();
    }
    if(t5->interval()!=0)
    {
        d5->close();
        t5->stop();
    }
    if(t9->interval()!=0)
    {
        d9->close();
        t9->stop();
    }
    if(t13->interval()!=0)
    {
        d13->close();
        t13->stop();
    }
}
void MainWindow::robot()
{
    rob=new QTimer;
    rob->start();
    rob->setInterval(500);
    connect(rob,SIGNAL(timeout()),this,SLOT(hod_r()));
}
void MainWindow::proverka_t()
{
    dice_button->setEnabled(true);
    t8->stop();
    d8->close();
    int a=rand()%6+1;
    dice_info->setText(QString::number(a));
    if(a<4)
    {
        dice_info->setText("Увы,но вы идёте назад(((");
        a*=-1;
        go_t(a);
    }
}
void MainWindow::hod_r()
{
    int a;
    rob->stop();
    hod1++;
    int num=rand()%6+1;
    list_of_moves[hod1]+=num;
    dice_info->setText(QString::number(num));
    QChar c=hod[hod1];
    QString s1;
    int k=0;
    QString s=((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text();
    for(int i=0;i<s.size();i++)
    {
        if(s[i]==hod[hod1])
            continue;
        s1[k]=s[i];
        k++;
    }
    ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(s1);
    list_of_moves[hod1]+=num;
    if(list_of_moves[hod1]<34)
    {
        ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(c+((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text());
        QTableWidgetItem *item = new QTableWidgetItem; // изменение позиции в таблице
        item->setText(QString::number(list_of_moves[hod1]+1));
        ui->tableWidget->setItem(hod1,1, item);
    }
    else
    {
        ((QLabel*)layout->itemAt(34)->widget())->setText(name_of_player[hod1]);
        QPushButton *b=(QPushButton*)sender();
        b->setEnabled(false);
        QTableWidgetItem *item = new QTableWidgetItem;
        Victory winner=new Victory(this,name_of_player[hod1],hod1);
        item->setText("35");
        ui->tableWidget->setItem(hod1,1, item);
        mp3_player->stop();
    }
    switch (list_of_moves[hod1]+1) {
    case 2:
        d1->show();
        t1=new QTimer();
        t1->start();
        t1->setInterval(300);
        connect(t1,SIGNAL(timeout()),this,SLOT(kubik_t()));
        dice_button->setEnabled(false);
        break;
    case 4:
        d2->show();
        t2=new QTimer();
        t2->start();
        t2->setInterval(300);
        connect(t2,SIGNAL(timeout()),this,SLOT(skip_t()));
        dice_button->setEnabled(false);
        break;
    case 6:
        d3->show();
        a=rand()%2;
        if(a)
        {
            t3=new QTimer();
            t3->start();
            t3->setInterval(300);
            connect(t3,SIGNAL(timeout()),this,SLOT(go_1_t()));
        }
        else
        {
            t3=new QTimer();
            t3->start();
            t3->setInterval(300);
            connect(t3,SIGNAL(timeout()),this,SLOT(skip_t()));
        }
        dice_button->setEnabled(false);
        break;
    case 8:
        d4->show();
        t4=new QTimer();
        t4->start();
        t4->setInterval(300);
        connect(t4,SIGNAL(timeout()),this,SLOT(go_3_t()));
        dice_button->setEnabled(false);
        break;
    case 10:
        d5->show();
        a=rand()%2;
        if(a)
        {
            t5=new QTimer();
            t5->start();
            t5->setInterval(300);
            connect(t5,SIGNAL(timeout()),this,SLOT(skip_t()));
        }
        else
        {
            t5=new QTimer();
            t5->start();
            t5->setInterval(300);
            connect(t5,SIGNAL(timeout()),this,SLOT(go__1_t()));
        }
        dice_button->setEnabled(false);
        break;
    case 13:
        d6->show();
        t6=new QTimer();
        t6->start();
        t6->setInterval(300);
        connect(t6,SIGNAL(timeout()),this,SLOT(go_end_t()));
        dice_button->setEnabled(false);
        break;
    case 15:
        d7->show();
        t7=new QTimer();
        t7->start();
        t7->setInterval(300);
        connect(t7,SIGNAL(timeout()),this,SLOT(kubik_t()));
        dice_button->setEnabled(false);
        break;
    case 17:
        d8->show();
        t8=new QTimer();
        t8->start();
        t8->setInterval(300);
        connect(t8,SIGNAL(timeout()),this,SLOT(proverka_t()));
        dice_button->setEnabled(false);
        break;
    case 19:
        d9->show();
        dice_button->setEnabled(false);
        a=rand()%2;
        if(a)
        {
            t9=new QTimer();
            t9->start();
            t9->setInterval(300);
            connect(t9,SIGNAL(timeout()),this,SLOT(skip_t()));
        }
        else
        {
            t9=new QTimer();
            t9->start();
            t9->setInterval(300);
            connect(t9,SIGNAL(timeout()),this,SLOT(go_1_t()));
        }
        break;
    case 22:
        d10->show();
        dice_button->setEnabled(false);
        a=rand()%2;
        if(a)
        {
            t10=new QTimer();
            t10->start();
            t10->setInterval(300);
            connect(t10,SIGNAL(timeout()),this,SLOT(go__4_t()));
        }
        else
        {
            t10=new QTimer();
            t10->start();
            t10->setInterval(300);
            connect(t10,SIGNAL(timeout()),this,SLOT(go__6_t()));
        }
        break;
    case 25:
        d11->show();
        t11=new QTimer();
        t11->start();
        t11->setInterval(300);
        connect(t11,SIGNAL(timeout()),this,SLOT(go__5_t()));
        dice_button->setEnabled(false);
        break;
    case 27:
        d12->show();
        t12=new QTimer();
        t12->start();
        t12->setInterval(300);
        connect(t12,SIGNAL(timeout()),this,SLOT(go_end_t()));
        dice_button->setEnabled(false);
        break;
    case 30:
        d13->show();
        a=rand()%2;
        if(a)
        {
            t13=new QTimer();
            t13->start();
            t13->setInterval(300);
            connect(t13,SIGNAL(timeout()),this,SLOT(skip_t()));
        }
        else
        {
            t13=new QTimer();
            t13->start();
            t13->setInterval(300);
            connect(t13,SIGNAL(timeout()),this,SLOT(go_start_t()));
        }
        dice_button->setEnabled(false);
        break;
    case 32:
        d14->show();
        t14=new QTimer();
        t14->start();
        t14->setInterval(300);
        connect(t14,SIGNAL(timeout()),this,SLOT(skip_t()));
        dice_button->setEnabled(false);
        break;
    case 34:
        d15->show();
        t15=new QTimer();
        t15->start();
        t15->setInterval(300);
        connect(t15,SIGNAL(timeout()),this,SLOT(skip_t()));
        dice_button->setEnabled(false);
        break;
    default:
        break;
    }

}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::get_name(QString a)
{
    name_of_player[0]=a;
}
void MainWindow::paintEvent(QPaintEvent*)
{

}
void MainWindow::go_t(int a)
{
    if(t12->interval()!=0)
    {
        d12->close();
        t12->stop();
    }
    if(t11->interval()!=0)
    {
        d11->close();
        t11->stop();
    }
    if(t10->interval()!=0)
    {
        d10->close();
        t10->stop();
    }
    if(t3->interval()!=0)
    {
        d3->close();
        t3->stop();
    }
    if(t4->interval()!=0)
    {
        d4->close();
        t4->stop();
    }
    if(t5->interval()!=0)
    {
        d5->close();
        t5->stop();
    }
    if(t6->interval()!=0)
    {
        d6->close();
        t6->stop();
    }
    if(t9->interval()!=0)
    {
        d9->close();
        t9->stop();
    }
    if(t13->interval()!=0)
    {
        d13->close();
        t13->stop();
    }
    dice_button->setEnabled(true);
    QString s=((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text();
    list_of_moves[hod1]+=a;
    QString s1;
    int k=0;

    for(int i=0;i<s.size();i++)
    {
        if(s[i]==hod[hod1])
            continue;
        s1[k]=s[i];
        k++;
    }
    ((QLabel*)layout->itemAt(list_of_moves[hod1]-a)->widget())->setText(s1);
    QChar c=hod[hod1];
    ((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->setText(c+((QLabel*)layout->itemAt(list_of_moves[hod1])->widget())->text());
    QTableWidgetItem *item = new QTableWidgetItem; // изменение позиции в таблице
    item->setText(QString::number(list_of_moves[hod1]+1));
    ui->tableWidget->setItem(hod1,1, item);
    if(list_of_moves[hod1]+1==19)
    {
        list_of_skips[hod1]++;
    }
    if(list_of_moves[hod1]+1==22||list_of_moves[hod1]==33)
    {
        list_of_skips[hod1]+=2;
    }
}
void MainWindow::go_3_t()
{
    go_t(3);
}

void MainWindow::go_start_t()
{
    int a=33-list_of_moves[hod1];
    go_t(a);
}
void MainWindow::go_end_t()
{
    int a=list_of_moves[hod1]*(-1);
    go_t(a);
}
void MainWindow::go__5_t()
{
    go_t(-5);
}
void MainWindow::go_1_t()
{
    go_t(1);
}
void MainWindow::go__1_t()
{
    go_t(-1);
}

void MainWindow::go__4_t()
{
    go_t(-4);
}

void MainWindow::go__6_t()
{
    go_t(-6);
}
void MainWindow::keyPressEvent(QKeyEvent *eventy)
{
    int key=eventy->key();
    if(key==Qt::Key_Space)
    {
        Dice_button_clicked();
    }
}
