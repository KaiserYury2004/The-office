#include "event.h"

Event::Event() : text(""), cell_num(0), act(Dismissal), count(0), choise1(Dismissal), choise2(Dismissal)
{
}

Event::Event(QString str, int num, Action act, int _count, Action _choise1, Action _choise2) : text(str), cell_num(num), act(act), count(_count), choise1(_choise1), choise2(_choise2)
{
}

Event::Event(const Event& other) : text(other.text), cell_num(other.cell_num), act(other.act), count(other.count), choise1(other.choise1), choise2(other.choise2)
{
}

Event& Event:: operator=(const Event& other) {
    text = other.text;
    cell_num = other.cell_num;
    act = other.act;
    count = other.count;
    choise1 = other.choise1;
    choise2 = other.choise2;
    return *this;
}

int Event:: GetCell_num() {
    return cell_num;
}
Action Event:: GetAct() {
    return act;
}

int Event:: GetCount() {
    return count;
}

QString Event:: GetText() {
    return text;
}

Action Event:: GetChoise1() {
    return choise1;
}

Action Event:: GetChoise2() {
    return choise2;
}
