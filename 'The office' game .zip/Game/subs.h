#include<QLabel>
#include <QMainWindow>
#include<QGraphicsScene>
#include<QGraphicsPixmapItem>
#include<QGraphicsItem>
#include<QGraphicsView>
#include<QGraphicsTextItem>
class subs : public QMainWindow

{
    Q_OBJECT

public:
    subs(QWidget *parent = nullptr);
    ~subs();
private slots:
    void scroll();
private:
    QGraphicsScene *scene;
    QTimer* zeit;
    QLabel *subtitles;
    QLabel *gif;
    int scrolling;
    QGraphicsView *view;
    //QGraphicsTextItem *text;

};

