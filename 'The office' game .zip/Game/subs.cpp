#include "subs.h"
#include <QMainWindow>
#include<QGraphicsPixmapItem>
#include<QGraphicsScene>
#include<QGraphicsTextItem>
#include<QGraphicsView>
#include<QGraphicsItem>
#include<QTimer>
#include<QTime>
#include<QDebug>
#include<QMovie>
subs::subs(QWidget *parent)
    : QMainWindow(parent)

{
    setFixedSize(960,540);
    view=new QGraphicsView(this);
    gif=new QLabel(this);
    gif->setGeometry(0,350,252,211);
    view->setGeometry(0,0,960,601);
    QMovie *mv = new QMovie(":/pig-laptop.gif");
    mv->start();
    scene=new QGraphicsScene(this);
    scene->setBackgroundBrush(Qt::black);
    view->setScene(scene);
    scene->addRect(scene->sceneRect());
    subtitles=new QLabel(this);
    zeit=new QTimer(this);
    gif->setMovie(mv);
    scene->addWidget(gif);
    scrolling=500;
    subtitles->setText("     Stein  Production  Company presents\n\n                        The Office game \n\n"
                       "                           Creators:\n\nTeam Leader                               J.Stayan\n\n"
                       "Main Programmer                      M.Anikeyenka\n\n"
                       "Main Programmer                      J.Stayan\n\n"
                       "Programmer-Designer              K.Yurasyuk\n\n"
                       "Programmer                               E.Pushkarev\n\n"
                       "Main Designer                            D.Bondarenko\n\n"
                       "Visual Designer                          V.Khmelnitsky\n\n"
                       "Designer                                     H.Astapuk\n\n"
                       "Designer                                     P.Stepanovich\n\n"
                       "Designer                                     S.Kovaleva\n\n"
                       "Creative director                       D.Bondarenko\n\n"
                       "Music                                          J.Stayan\n\n"
                       "Tester                                         M.Anikeyenka\n\n"
                       "Tester                                         E.Legend\n\n"
                       "Tester                                         K.Yurasyuk\n\n"
                       "Gratitude to                               N.Lukyanov\n\n"
                       "Gratitude to                               A.Bezverkhi\n\n"
                       "          Thanks for choosing our game :)"
                       "");
    subtitles->setStyleSheet("font: bold 24px;"
                             "color:white;");
    subtitles->setGeometry(320,scrolling,1000,800);
    connect(zeit,SIGNAL(timeout()),this,SLOT(scroll()));
    zeit->setInterval(12);
    //20-orig
    //
    zeit->start();
}
void subs::scroll()
{
    scrolling=scrolling-1;
    subtitles->setGeometry(320,scrolling,1000,1400);
}
subs::~subs()
{

}
