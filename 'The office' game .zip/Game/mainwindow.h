#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include<QLabel>
#include<QPushButton>
#include<QGridLayout>
#include<QTextEdit>
#include<QTableWidget>
#include<QMessageBox>
#include<QPushButton>
#include <QShortcut>
#include<QGraphicsScene>
#include<QPixmap>
#include<QTimer>
#include<QGraphicsRectItem>
#include<QtMultimedia/QSound>
#include<QMediaPlayer>
#include "event.h"
#include <QVector>
#include <QTimer>
#include <QShortcut>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
class MainWindow : public QMainWindow
{
    Q_OBJECT

    int myTimer;
public:
    MainWindow(QWidget *parent = nullptr,int counter=0);
    ~MainWindow();
    void robot();
private:
    QVector<QString> names;
    QMovie *ac1;
    QMovie *ac2;
    QMovie *ac3;
    QMovie *ac4;
    QMovie *ac5;
    QMovie *ac6;
    QMovie *ac7;
    QMovie *ac8;
    QMovie *ac9;
    QMovie *ac10;
    QMovie *ac11;
    QMovie *ac12;
    QMovie *ac13;
    QMovie *ac14;
    QMovie *ac15;

    Ui::MainWindow *ui;
    QString name1="Player1",name2="Player2",name3="Player3",name4="Player4";
    QGridLayout *layout;
    QLabel *dice_info;
    QPushButton *dice_button;
    QPushButton *b;
    QMediaPlayer *mp3_player;
    int counter;
    int number_of_player;
    int list_of_moves[4]={0,0,0,0};
    int list_of_skips[4]={0,0,0,0};
    QString name_of_player[4]={" "," "," "," "};
    Event events[35];


    QTimer *t1;
    QTimer *t2;
    QTimer *t3;
    QTimer *t4;
    QTimer *t5;
    QTimer *t6;
    QTimer *t7;
    QTimer *t8;
    QTimer *t9;
    QTimer *t10;
    QTimer *t11;
    QTimer *t12;
    QTimer *t13;
    QTimer *t14;
    QTimer *t15;
    QDialog *d1;
    QDialog *d2;
    QDialog *d3;
    QDialog *d4;
    QDialog *d5;
    QDialog *d6;
    QDialog *d7;
    QDialog *d8;
    QDialog *d9;
    QDialog *d10;
    QDialog *d11;
    QDialog *d12;
    QDialog *d13;
    QDialog *d14;
    QDialog *d15;

    QTimer *rob;
    QLabel *l1;
    QLabel *l2;
    QLabel *l3;
    QLabel *l4;
    QLabel *l5;
    QLabel *l6;
    QLabel *l7;
    QLabel *l8;
    QLabel *l9;
    QLabel *l10;
    QLabel *l11;
    QLabel *l12;
    QLabel *l13;
    QLabel *l14;
    QLabel *l15;
    bool h=1;
    bool roll=0;
signals:
public slots:
    void set_name1(QString a)
    {
        name1=a;
    }
    void set_name2(QString a)
    {
        name2=a;
    }
    void set_name3(QString a)
    {
        name3=a;
    }
    void set_name4(QString a)
    {
        name4=a;
    }
    void set_tabl_names();
    void get_name(QString a);
private slots:

    void hod_r();
    void kubik_t();
    void skip_t();
    void go_3_t();
    void go_1_t();
    void go__1_t();
    void go__4_t();
    void go__5_t();
    void go_end_t();
    void go_start_t();
    void go__6_t();
    void go_t(int a);
    void proverka_t();

    void proverka();
    void skip();
    void kubik();
    void go_3();
    void go_1();
    void go__1();
    void go__4();
    void go__5();
    void go_end();
    void go_start();
    void go__6();
    void go(int a);


    void Dice_button_clicked();
    void paintEvent(QPaintEvent*);
    void keyPressEvent(QKeyEvent *eventy);
};
#endif // MAINWINDOW_H
